import 'package:flutter/material.dart';

void main() => runApp(const PakSchoolManager());

class PakSchoolManager extends StatelessWidget {
  const PakSchoolManager({super.key});

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF10264A);
    const blue = Color(0xFF2563EB);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Pak School Manager',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: blue),
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: navy,
          elevation: 0,
          centerTitle: false,
        ),
      ),
      home: const DashboardScreen(),
    );
  }
}

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = const [
      _Metric('Students', '1,248', Icons.groups_rounded, Color(0xFFE8F0FF)),
      _Metric('Teachers', '68', Icons.co_present_rounded, Color(0xFFE8F8F0)),
      _Metric('Classes', '32', Icons.meeting_room_rounded, Color(0xFFFFF3E5)),
      _Metric('Fees collected', 'Rs 845,000', Icons.payments_rounded, Color(0xFFF2EAFE)),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Pak School Manager', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
            Text('Multi-school administration', style: TextStyle(fontSize: 11, color: Colors.blueGrey)),
          ],
        ),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded)),
          const Padding(
            padding: EdgeInsets.only(right: 16),
            child: CircleAvatar(
              backgroundColor: Color(0xFFE8F0FF),
              child: Icon(Icons.person, color: Color(0xFF2563EB)),
            ),
          ),
        ],
      ),
      drawer: const _AppDrawer(),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final columns = constraints.maxWidth > 850 ? 4 : (constraints.maxWidth > 520 ? 2 : 2);
          return SingleChildScrollView(
            padding: const EdgeInsets.all(18),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1150),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [Color(0xFF10264A), Color(0xFF2456A6)]),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Welcome back, Admin', style: TextStyle(color: Colors.white70, fontSize: 13)),
                          SizedBox(height: 8),
                          Text('School overview', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                          SizedBox(height: 6),
                          Text('Manage your school from one place.', style: TextStyle(color: Colors.white70)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 22),
                    const Text('Overview', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: Color(0xFF10264A))),
                    const SizedBox(height: 12),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: items.length,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: columns,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: constraints.maxWidth < 380 ? 1.2 : 1.55,
                      ),
                      itemBuilder: (context, index) => _MetricCard(metric: items[index]),
                    ),
                    const SizedBox(height: 22),
                    const Text('Quick actions', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: Color(0xFF10264A))),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: [
                        _ActionChip('Add student', Icons.person_add_alt_1),
                        _ActionChip('Take attendance', Icons.fact_check_outlined),
                        _ActionChip('Collect fee', Icons.receipt_long),
                        _ActionChip('Add teacher', Icons.school_outlined),
                      ],
                    ),
                    const SizedBox(height: 22),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                      child: const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Getting started', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          SizedBox(height: 8),
                          Text('This is the first UI prototype. Firebase sign-in, school registration, tenant security and live records will be connected in the next development phase.',
                            style: TextStyle(color: Colors.black54, height: 1.45)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _Metric {
  final String label, value;
  final IconData icon;
  final Color tint;
  const _Metric(this.label, this.value, this.icon, this.tint);
}

class _MetricCard extends StatelessWidget {
  final _Metric metric;
  const _MetricCard({required this.metric});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(padding: const EdgeInsets.all(9), decoration: BoxDecoration(color: metric.tint, borderRadius: BorderRadius.circular(11)),
          child: Icon(metric.icon, color: const Color(0xFF2456A6), size: 21)),
        const SizedBox(height: 10),
        Text(metric.value, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: Color(0xFF10264A))),
        Text(metric.label, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 11, color: Colors.black54)),
      ],
    ),
  );
}

class _ActionChip extends StatelessWidget {
  final String label;
  final IconData icon;
  const _ActionChip(this.label, this.icon);

  @override
  Widget build(BuildContext context) => ActionChip(
    avatar: Icon(icon, size: 18, color: const Color(0xFF2563EB)),
    label: Text(label),
    onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$label module will be connected in the next phase.')),
    ),
    backgroundColor: Colors.white,
    side: BorderSide.none,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
  );
}

class _AppDrawer extends StatelessWidget {
  const _AppDrawer();

  @override
  Widget build(BuildContext context) => Drawer(
    child: ListView(
      padding: EdgeInsets.zero,
      children: [
        const DrawerHeader(
          decoration: BoxDecoration(color: Color(0xFF10264A)),
          child: Align(
            alignment: Alignment.bottomLeft,
            child: Text('Pak School Manager\nAdmin Menu',
              style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
          ),
        ),
        _nav(Icons.dashboard_outlined, 'Dashboard'),
        _nav(Icons.apartment_outlined, 'Schools'),
        _nav(Icons.groups_outlined, 'Students'),
        _nav(Icons.co_present_outlined, 'Teachers'),
        _nav(Icons.meeting_room_outlined, 'Classes'),
        _nav(Icons.fact_check_outlined, 'Attendance'),
        _nav(Icons.payments_outlined, 'Fees'),
        _nav(Icons.menu_book_outlined, 'Exams & Results'),
        _nav(Icons.bar_chart_outlined, 'Reports'),
        _nav(Icons.settings_outlined, 'Settings'),
      ],
    ),
  );

  Widget _nav(IconData icon, String title) => ListTile(
    leading: Icon(icon, color: const Color(0xFF2456A6)),
    title: Text(title),
    onTap: () {},
  );
}
