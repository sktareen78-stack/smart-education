# Pak School Manager - Starter

This is Phase 1: a Flutter UI prototype for Android and Web, with Firebase dependencies and an initial multi-tenant Firestore security-rules draft.

## Recommended stack
- Flutter: one codebase for Android and Web
- Firebase Authentication: sign-in
- Cloud Firestore: school and school-scoped records
- Cloud Storage: student photos and documents (to be configured)
- Cloud Functions: trusted school registration, role provisioning and subscription workflows (to be implemented)

## Run the UI prototype
1. Install Flutter SDK and Android Studio.
2. Extract this project.
3. Run `flutter pub get`.
4. Run `flutter run` for an Android emulator/device.
5. Run `flutter run -d chrome` for Web.

## Firebase connection (next phase)
1. Create a Firebase project.
2. Enable Authentication providers you want to use.
3. Create a Firestore database.
4. Install FlutterFire CLI and run `flutterfire configure`.
5. Initialize Firebase in `main.dart` before using Firebase services.

## Important security notes
- The dashboard currently uses sample figures. It is not connected to a live database.
- Do not publish this prototype as a production school system yet.
- The Firestore rules are a starting draft. Test them with the Firebase Emulator Suite before deployment.
- Provision `users/{uid}` documents and `platformAdmin` custom claims only from trusted server-side code. Never let a client choose its own role or school ID.
- Add per-role permissions for teachers, parents and students before enabling those accounts.
- Add validation, audit logs, backups, privacy notices and data-retention policies before storing real student data.

## Initial data structure
- `users/{uid}`: `schoolId`, `role`, `status`, `displayName`
- `schools/{schoolId}`: school profile, subscription status
- `schools/{schoolId}/students/{studentId}`
- `schools/{schoolId}/teachers/{teacherId}`
- `schools/{schoolId}/classes/{classId}`
- `schools/{schoolId}/attendance/{attendanceId}`
- `schools/{schoolId}/fees/{feeId}`
- `schools/{schoolId}/exams/{examId}`
- `schools/{schoolId}/results/{resultId}`

## Next development milestone
Build Firebase initialization, login, school registration through a trusted backend function, and role-based routing for Platform Admin and School Admin.
